<?php
  if(session_id() == '') {
    session_start();
  }
  $urls = explode('.', $_SERVER['HTTP_HOST']);
  if($urls[0] != 'www'){
    header( "Location: https://www.natana.in/pulse");
  }

  ini_set('display_errors', '1');
  require_once('connect.php');
  require_once __DIR__ . '/vendor/autoload.php'; // change path as needed
  

  $fb = new \Facebook\Facebook([
    'app_id' => '1015039395350327',
    'app_secret' => 'd2248d8099a1e7cb10e14426e56e171c',
    'default_graph_version' => 'v2.10',
    //'default_access_token' => '{access-token}', // optional
  ]);

  
  $helper = $fb->getRedirectLoginHelper();

  if(!isset($_SESSION['fb_access_token'])){
    $permissions = ['email']; // Optional permissions
    $loginUrl = $helper->getLoginUrl('https://natana.in/pulse/fb-callback.php', $permissions);
  // echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';
  }else{
    try {
      // Get the \Facebook\GraphNodes\GraphUser object for the current user.
      // If you provided a 'default_access_token', the '{access-token}' is optional.
      $accessToken = $_SESSION['fb_access_token'];  
      $response = $fb->get('/me?fields=id,name,picture,email',$accessToken);
    } catch(\Facebook\Exceptions\FacebookResponseException $e) {
      // When Graph returns an error
      echo 'Graph returned an error: ' . $e->getMessage();
      exit;
    } catch(\Facebook\Exceptions\FacebookSDKException $e) {
      // When validation fails or other local issues
      echo 'Facebook SDK returned an error: ' . $e->getMessage();
      exit;
    }
    
    $me = $response->getGraphUser();
  }
  $permissions = ['email'];
  $loginUrl = $helper->getLoginUrl('https://natana.in/pulse/fb-callback.php', $permissions);


  
  //start login with facebook?
  if( isset( $_GET["login"] ) ){
    if($_GET["login"] == 'facebook'){
      $type = 1;
    }else{
      $type = 2;
    }
  
    try{

      $_SESSION['provider'] = $_GET["login"];
      $_SESSION['pulse_id'] = $me->getId(); //profile id

      $user_detail = select_with_email($me->getEmail(),$type); //Replace with email from new API
      
      if(!$user_detail){

        $res = insert($me->getName(), $me->getEmail(), "", $type); //Change these data
        if($res){
            $user_detail = select_with_email($me->getEmail(),$type);
            $_SESSION['pulse_user_id'] = $user_detail['social_user_id'];
            header( "Location: instructions.php"  );
        }
      }else{
        $_SESSION['pulse_user_id'] = $user_detail['social_user_id'];
        header( "Location: instructions.php"  );
      }
      //print_r($user_profile);
    }
    catch( Exception $e ){
      //die( "<b>got an error!</b> " . $e->getMessage() ); 
      if($e->getMessage()){
       // die( "<b>got an error!</b> " . $e->getMessage() ); 
        header( "Location: ../pulse/index.php" );
      }
    }
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Natana Pulse</title>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<link href="css/pulse.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="login">
<section class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <h3 class="slogan text-center">WELCOME TO NATANA PULSE</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <p class="natana-logo"><img src="images/natana_logo.png" alt="Natana" class="img-responsive"></p>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <h4 class="text-center login">LOGIN</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <div class="text-center">
        <div class="text-center btn-group social"> <a href="<?=htmlspecialchars($loginUrl)?>" class="btn btn-primary"><i class="fa fa-facebook"></i> Facebook</a> </div>
      </div>
    </div>
  </div>
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>