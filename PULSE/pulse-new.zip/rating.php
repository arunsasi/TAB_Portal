<?php
if(session_id() == '') {
    session_start();
}
if(!isset($_SESSION['pulse_user_id'])){
    header('Location: index.php');
}

include "connect.php";
$ratingcount	= $_POST['count'];
$teamname 		= $_POST['teamname'];
$userid 		= $_POST['userid'];
$ratingExist 	= ratingDataExist($userid,$teamname);
if($ratingExist){
ratingUpdate($ratingcount, $userid, $teamname);
echo "success";
}else{
ratingInsert($teamname,$ratingcount,$userid);
echo "success";
}
?>