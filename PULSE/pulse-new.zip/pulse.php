<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if(session_id() == '') {
          session_start();
  }
//   if(!isset($_SESSION['pulse_id'])){
//       header('Location: index.php');
//   }
include "connect.php";
$ratingArray = array();

for($i=1; $i<=14; $i++){
    $teamname = 'b'.$i;       
    $upadteRating           = ratingDataExist($_SESSION['pulse_user_id'],$teamname); 
    $teamname               = isset($upadteRating['rating_team_name'])? $upadteRating['rating_team_name'] : $teamname ;
    $count                  = isset($upadteRating['rating_count'])?$upadteRating['rating_count']:0.0;
    $ratingArray['b'.$i]    = $count;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Natana Pulse</title>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link href="css/jalwa.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<link href="css/star-rating.min.css" media="all" rel="stylesheet" type="text/css"/>
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="jalwa_bg">
<div id="fb-root"></div>

<section class="container">
    <div class="row">
    <div class="col-xs-12 col-sm-12">
      <h3 class="slogan text-center">Band Wars POLL</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <div class="whitebox margin-remove">
           <?php for($i=1;$i<=6;$i++) {?>
            <div class="pulse-poll">
            <div class="row">
            <div class="col-xs-3 col-sm3"><div class="team-number">B<?=$i?></div></div>
            <div class="col-xs-9 col-sm9"><div class="star-rating"> <input id="input-<?=$i?>e" value="<?=isset($ratingArray['b'.$i])?$ratingArray['b'.$i]:''?>" type="number" class="rating" min=0 max=5 step=0.5 data-size="xs" ></div></div>
            </div>
            </div><?php } ?>
        <input type="hidden" id="userid" value="<?=isset($_SESSION['pulse_user_id'])?$_SESSION['pulse_user_id']:''?>" />
        <div class="text-center social"><div class="fb-like" class="btn btn-primary btn-block" data-href="https://www.facebook.com/Natanatechnopark" data-layout="standard" data-action="like" data-show-faces="false" data-share="true" layout="button_count"></div></div>
        <div class="text-center policy"><a class="read-privacy"> * Read our Privacy Policy </a></div>
      </div>
    </div>
  </div>
</section>
<div class="popup-wrap" id="read-privacy">
    <div class="popup-overlay"></div>
    <div class="popup">
        <div class="popup-content">
            <div class="whitebox">
                <p class="text-justify">In order to participate in the NATANA pulse poll, you may be asked to enter your Facebook login details to help track your poll responses and ensuring a customised user experience. We / our event partner may use the information we collect from such sign up to periodically inform you about our upcoming activities or products/services. By entering the details you consent to the receipt of such mails from us/partners with an opt-out facility if you do not wish to be in the mailing list. We do not use cookies for tracking purposes nor collect any personal information. We do not sell, trade or otherwise transfer Personally Identifiable Information.</p>
            </div>
        </div>
        <a class="popup-close"></a>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="js/star-rating.js" type="text/javascript"></script>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1481189508804293&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script>
    jQuery(document).ready(function () {

        $('.read-privacy').click(function(){
            $('#read-privacy').fadeIn(500);
        });
        $('.popup-close').click(function(){
            $('#read-privacy').fadeOut(0);
        });

        $('#input-1e').on('rating.change', function(event, value, captions) {
        //$("#input-1e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b1';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   

            }  
     });
    }); 
       $('#input-2e').on('rating.change', function(event, value, captions) {
        //$("#input-2e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b2';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   

            }  
     });
    }); 
    $('#input-3e').on('rating.change', function(event, value, captions) {
        //$("#input-3e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b3';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   
                                                           
            }  
     });
    });  
    $('#input-4e').on('rating.change', function(event, value, captions) {
        //$("#input-4e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b4';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   
                                                           
            }  
     });
    });
    $('#input-5e').on('rating.change', function(event, value, captions) {
        //$("#input-5e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b5';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   
                                                           
            }  
     });
    }); 
    $('#input-6e').on('rating.change', function(event, value, captions) {
        //$("#input-6e").rating("refresh", {disabled: true, showClear: false});
         var count    =  value;
         var teamname =  'b6';
         var userid   =  $('#userid').val();
         $.ajax({
            type: 'POST',
            url: 'rating.php', 
            data:'count='+count+'&teamname='+teamname+'&userid='+userid,
            success: function(data) 
            {   
                                                            
            }  
     });
    });
    // $('#input-7e').on('rating.change', function(event, value, captions) {
    //     //$("#input-7e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j7';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                            
    //         }  
    //  });
    // });
    // $('#input-8e').on('rating.change', function(event, value, captions) {
    //     //$("#input-8e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j8';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                          
    //         }  
    //  });
    // });
    // $('#input-9e').on('rating.change', function(event, value, captions) {
    //     //$("#input-9e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j9';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                              
    //         }  
    //  });
    // }); 
    // $('#input-10e').on('rating.change', function(event, value, captions) {
    //     //$("#input-10e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j10';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                              
    //         }  
    //  });
    // }); 
    // $('#input-11e').on('rating.change', function(event, value, captions) {
    //     //$("#input-11e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j11';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                     
    //         }  
    //  });
    // }); 
    // $('#input-12e').on('rating.change', function(event, value, captions) {

    //     //$("#input-11e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j12';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                             
    //         }  
    //  });
    // });
    // $('#input-13e').on('rating.change', function(event, value, captions) {
    //     //$("#input-11e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j13';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                            
    //         }  
    //  });
    // });
    // $('#input-14e').on('rating.change', function(event, value, captions) {
    //     //$("#input-11e").rating("refresh", {disabled: true, showClear: false});
    //      var count    =  value;
    //      var teamname =  'j14';
    //      var userid   =  $('#userid').val();
    //      $.ajax({
    //         type: 'POST',
    //         url: 'rating.php', 
    //         data:'count='+count+'&teamname='+teamname+'&userid='+userid,
    //         success: function(data) 
    //         {   
                                                            
    //         }  
    //  });
    // });
});        
</script>
</body>
</html>