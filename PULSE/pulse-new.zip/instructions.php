<?php
  if(session_id() == '') {
      session_start();
  }
  if(!$_SESSION['pulse_id']){
      header('location:index.php');
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Natana Pulse</title>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<link href="css/jalwa.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<script src=""></script>
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<style type="text/css">
  ._51mz {
    width: 100% !important;
  }
</style>
</head>
<body class="jalwa_bg">

<div id="fb-root"></div>

<section class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <p class="bm-logo"><img src="images/natana.png" alt="Best Matrimony Online" class="img-responsive"></p>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <h3 class="slogan text-center">Band Wars POLL</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-12">
      <div class="whitebox">
        <p class="text-center text-lg">INSTRUCTIONS</p>
        <ul class="instructions">
          <li>Band Wars poll will run immediately after the first team on stage.</li>
          <li>You can rate a team’s performance on a scale of 1 - 5 by clicking on the stars</li>
          <li>Once you click, your choice shall be automatically submitted</li>
          <li>You can login and rate a teams performance anytime till the event is officially over.</li>
        </ul>
        <div class="text-center social">
          <div class="text-center social">
            <div class="fb-like" class="btn btn-primary btn-block" data-href="https://www.facebook.com/Wall-234645533600413" data-layout="standard" data-action="like" data-show-faces="false" data-share="true" layout="button_count">
            </div>
          </div>
        <div class="text-center skip"><a href="pulse.php" class="btn btn-warning btn-sm"><i class="fa fa-angle-left"></i> SKIP <i class="fa fa-angle-right"></i></a></div>
      </div>
    </div>
  </div>
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1481189508804293&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

jQuery(window).bind("load resize", function(){    
  var container_width = jQuery('#container').width();    
    jQuery('#container').html('<div class="fb-like-box" ' + 
    'data-href="https://www.facebook.com/adobegocreate"' +
    ' data-width="' + container_width + '" data-height="730" data-show-faces="false" ' +
    'data-stream="true" data-header="true"></div>');
    FB.XFBML.parse( );    
}); 

</script>
</body>
</html>