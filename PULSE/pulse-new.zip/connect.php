<?php

	// $host   = "10.168.10.208";
	// $userdb = "root";
	// $pwddb  = "root";
	// $dbname = "kbnatana_website";

	$host   = "localhost";
	$userdb = "kbnatana_Usr";
	$pwddb  = "natanaPwd";
	$dbname = "kbnatana_website";
	/*$db=mysql_connect($host, $userdb, $pwddb) or DIE("error in connection");
	$db_selected = mysql_select_db($dbname, $db);*/

	$db_selected = mysqli_connect($host, $userdb, $pwddb, $dbname);
	// Check connection
	if (mysqli_connect_errno())
	  {
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  }

 	function insert($social_user_name, $social_user_email, $social_user_phone_number, $social_user_type){
		global $db_selected;
		$query = "INSERT INTO tab_social_2019(social_user_name, social_user_email, social_user_phone_number, social_user_type) VALUES ('$social_user_name','$social_user_email','$social_user_phone_number','$social_user_type')";
		$result = mysqli_query($db_selected,$query);
		return $result;
	}

	function select_with_email($email,$type){
		global $db_selected;
		$query = "SELECT * FROM tab_social_2019 WHERE social_user_email = '".$email."' AND social_user_type = '".$type."'";
		$result = mysqli_query($db_selected,$query);
		while ($row = mysqli_fetch_array($result)) {
			$res = $row;
		}
		return $res;
	}

	function ratingInsert($teamname, $ratingcount, $userid){
		global $db_selected;
		$query = "INSERT INTO tab_rating_2019(user_id, rating_team_name, rating_count) VALUES ('$userid','$teamname','$ratingcount')";
		$result = mysqli_query($db_selected,$query);
		return $result;

	}

	function select_with_userid($user_id){
		global $db_selected;
		$query = "SELECT * FROM tab_rating_2019 WHERE user_id = '".$user_id."'";
		$result = mysqli_query($db_selected,$query);
		while ($row = mysqli_fetch_array($result)) {
			$res = $row;
			return $res;
		}
		
	}
	function ratingDataExist($user_id, $teamname){
		global $db_selected;
		$query = "SELECT * FROM tab_rating_2019 WHERE user_id = '".$user_id."' AND rating_team_name = '".$teamname."'";
		$result = mysqli_query($db_selected,$query);
		$res = array();
		while ($row = mysqli_fetch_array($result)) {
			$res = $row;
		}
		return $res;

	}

	function ratingUpdate($ratingCount,$user_id,$teamName){
		global $db_selected;
		$query = "UPDATE tab_rating_2019 SET rating_count='".$ratingCount."' WHERE user_id='".$user_id."' AND rating_team_name='".$teamName."'";
		$result = mysqli_query($db_selected,$query);
		return $result;
	}

	function selectByCount(){
		global $db_selected;
		$query = "SELECT rating_team_name, SUM(rating_count) AS sum FROM tab_rating_2019  GROUP BY rating_team_name ORDER BY SUM(rating_count) DESC";
		$result = mysqli_query($db_selected,$query);
		while ($row = mysqli_fetch_array($result)) {
			$res[] = $row;
		}

		return $res;
	}

	function selectTeamRatingCount($teamName){
		global $db_selected;
		$query = "SELECT SUM(rating_count) AS sum FROM tab_rating_2019 WHERE rating_team_name = '". $teamName ."' ORDER BY SUM(rating_count)";
		$result = mysqli_query($db_selected,$query);
		while ($row = mysqli_fetch_array($result)) {
			$res[] = $row;
		}

		return $res;
	}

?>