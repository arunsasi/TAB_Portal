<?php
	if(session_id() == '') {
	  session_start();
	}
	if(!$_SESSION['pulse_user_id']){
	  header('location:index.php');
	}

	require_once('connect.php');
	$results = selectByCount();

	$ratingCount = array();

	/*foreach ($result as $teamName) {
		$ratingCount[] = selectTeamRatingCount($teamName['rating_team_name']);
	}*/

	//echo "<pre>"; print_r($results); echo "</pre>"; exit;

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Natana Pulse</title>
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
		<link href="css/jalwa.css" rel="stylesheet">
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400' rel='stylesheet' type='text/css'>
		<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
		<link href="css/star-rating.min.css" media="all" rel="stylesheet" type="text/css"/>
		<!--[if lt IE 9]>
		      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		    <![endif]-->
	</head>
	<body class="jalwa_bg">
		<div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1481189508804293&version=v2.0";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>
		<section class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12">
					<h3 class="slogan text-center">WALLAPPS.in Presents Jalwa 3 PULSE POLL</h3>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12">
					<div class="whitebox margin-remove">
						<?php foreach($results as $result) { ?>
						<?php if($result['rating_team_name']){ ?>
						<div class="pulse-poll">
							<div class="row">
								<div class="col-xs-3 col-sm3"><div class="team-number"><?php echo $result['rating_team_name']; ?></div></div>
								<div class="col-xs-9 col-sm9"><?php echo $result['sum']; ?></div>
							</div>
						</div>
						<?php } ?>
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
	</body>
</html>